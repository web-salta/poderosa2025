﻿
function base_url(url) { return '@(Url.Content("~/"))' + url; }
/***************seccion********************************/
var url2 = "https://www.poderosa.com.pe/participacion_ciudadana/contador";

$(document).ready(function () {
        $("form").submit(function () {
            var response = grecaptcha.getResponse();
            if (response.length == 0) {
                alert('Por favor chequear la Captcha');
                return false;
            } else {
                alert('todo bien');

                $.ajax({
                    type: 'post',
                    dataType: 'text',
                    url: url2,
                    beforeSend: function () {
                    },
                    success: function (result) {
                        $("p#count_click").text(result);
                    },

                    error: function (xhr, ajaxOptions, thrownError) {
                        alert(xhr.status + ' ' + thrownError);
                    }
                });
            }
        });
 });

var onloadCallback = function () {
    grecaptcha.render('html_element', {
        'sitekey': '6Lc_EJUmAAAAAFcJGGYkmWcou8AueS4OTcxVW1E_'
    });
};

   /* $("button[name='count_click']").click(function () {

        $.ajax({
            type: 'post',
            dataType: 'text',
            url: url2,
            beforeSend: function () {
            },
            success: function (result) {
                $("p#count_click").text(result);
            },

            error: function (xhr, ajaxOptions, thrownError) {
                alert(xhr.status + ' ' + thrownError);
            }
        });
    });*/

